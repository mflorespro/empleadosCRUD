﻿using EmpleadosWeb.Data;
using EmpleadosWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace EmpleadosWeb.Controllers
{
    public class EmpleadosController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly EmpleadoData _data;

        public EmpleadosController(IConfiguration configuration)
        {
            _configuration = configuration;
            _data = new EmpleadoData(_configuration.GetConnectionString("DefaultConnection"));
        }

        public IActionResult Index()
        {
            List<Empleado> lista = _data.Listar();
            return View("Index", lista); // Usa Index.cshtml
        }

        public IActionResult Create()
        {
            return View(); // Usa Create.cshtml por convención
        }

        [HttpPost]
        public IActionResult Guardar(Empleado emp)
        {
            if (!ModelState.IsValid)
                return View("Create", emp); // Usa Create.cshtml

            bool resultado = _data.Guardar(emp);
            if (resultado)
            {
                TempData["TipoMensaje"] = "success";
                TempData["Mensaje"] = "Empleado creado correctamente.";
                return RedirectToAction("Index");
            }

            TempData["TipoMensaje"] = "danger";
            TempData["Mensaje"] = "No se pudo guardar el empleado.";
            return View("Create", emp);
        }

        public IActionResult Edit(int id)
        {
            var empleado = _data.Obtener(id);
            if (empleado == null)
            {
                TempData["TipoMensaje"] = "warning";
                TempData["Mensaje"] = "Empleado no encontrado.";
                return RedirectToAction("Index");
            }

            return View("Edit", empleado); // Usa Edit.cshtml
        }

        [HttpPost]
        public IActionResult Edit(Empleado emp)
        {
            if (!ModelState.IsValid)
                return View("Edit", emp); // Usa Edit.cshtml

            bool resultado = _data.Editar(emp);
            if (resultado)
            {
                TempData["TipoMensaje"] = "success";
                TempData["Mensaje"] = "Empleado actualizado correctamente.";
                return RedirectToAction("Index");
            }

            TempData["TipoMensaje"] = "danger";
            TempData["Mensaje"] = "No se pudo actualizar el empleado.";
            return View("Edit", emp);
        }

        public IActionResult Delete(int id)
        {
            var empleado = _data.Obtener(id);
            if (empleado == null)
            {
                TempData["TipoMensaje"] = "warning";
                TempData["Mensaje"] = "Empleado no encontrado.";
                return RedirectToAction("Index");
            }

            return View("Delete", empleado); // Usa Delete.cshtml
        }

        [HttpPost]
        public IActionResult Eliminar(int id)
        {
            bool resultado = _data.Eliminar(id);
            if (resultado)
            {
                TempData["TipoMensaje"] = "success";
                TempData["Mensaje"] = "Empleado eliminado correctamente.";
            }
            else
            {
                TempData["TipoMensaje"] = "danger";
                TempData["Mensaje"] = "No se pudo eliminar el empleado.";
            }

            return RedirectToAction("Index");
        }


        public IActionResult ModalEditEmpleado(int id)
        {
            var empleado = _data.Obtener(id);
            if (empleado == null)
            {
                return NotFound();
            }

            return PartialView("Partials/_ModalEditEmpleado", empleado);
        }


        // AJAX: Obtener empleado por ID
        [HttpGet]
        public JsonResult ObtenerAjax(int id)
        {
            var empleado = _data.Obtener(id);
            return Json(empleado);
        }

        // AJAX: Crear empleado
        [HttpPost]
        public JsonResult CrearAjax([FromBody] Empleado emp)
        {
            var resultado = _data.Guardar(emp);
            return Json(new { success = resultado });
        }

        // AJAX: Editar empleado
        [HttpPost]
        public JsonResult EditarAjax([FromBody] Empleado emp)
        {
            var resultado = _data.Editar(emp);
            return Json(new { success = resultado });
        }

        // AJAX: Eliminar empleado
        [HttpPost]
        public JsonResult EliminarAjax([FromBody] int id)
        {
            var resultado = _data.Eliminar(id);
            return Json(new { success = resultado });
        }
    }
}
