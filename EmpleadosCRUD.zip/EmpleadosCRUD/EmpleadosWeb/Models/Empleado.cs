﻿using System.ComponentModel.DataAnnotations;

namespace EmpleadosWeb.Models
{
    public class Empleado
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio")]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "El apellido es obligatorio")]
        public string Apellido { get; set; }

        [Range(18, 65, ErrorMessage = "La edad debe estar entre 18 y 65 años")]
        public int Edad { get; set; }

        [EmailAddress(ErrorMessage = "Correo electrónico no válido")]
        public string Correo { get; set; }

        public string Departamento { get; set; }

        public string Puesto { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "El salario debe ser un valor positivo")]
        public decimal Salario { get; set; }
    }
}
