﻿using EmpleadosWeb.Models;
using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;

namespace EmpleadosWeb.Data
{
    public class EmpleadoData
    {
        private readonly DbHelper _db;

        public EmpleadoData(string connectionString)
        {
            _db = new DbHelper(connectionString);
        }

        public List<Empleado> Listar()
        {
            var lista = new List<Empleado>();
            var query = "SELECT Id, Nombre, Apellido, Edad, Correo, Departamento, Puesto, Salario FROM Empleados";
            var tabla = _db.ExecuteQuery(query);

            foreach (DataRow row in tabla.Rows)
            {
                lista.Add(new Empleado
                {
                    Id = Convert.ToInt32(row["Id"]),
                    Nombre = row["Nombre"].ToString(),
                    Apellido = row["Apellido"].ToString(),
                    Edad = Convert.ToInt32(row["Edad"]),
                    Correo = row["Correo"].ToString(),
                    Departamento = row["Departamento"].ToString(),
                    Puesto = row["Puesto"].ToString(),
                    Salario = Convert.ToDecimal(row["Salario"])
                });
            }

            return lista;
        }

        public Empleado Obtener(int id)
        {
            var query = "SELECT Id, Nombre, Apellido, Edad, Correo, Departamento, Puesto, Salario FROM Empleados WHERE Id = @Id";
            var parametros = new List<SqlParameter> { new SqlParameter("@Id", id) };
            var tabla = _db.ExecuteQuery(query, parametros);

            if (tabla.Rows.Count == 0) return null;

            var row = tabla.Rows[0];
            return new Empleado
            {
                Id = Convert.ToInt32(row["Id"]),
                Nombre = row["Nombre"].ToString(),
                Apellido = row["Apellido"].ToString(),
                Edad = Convert.ToInt32(row["Edad"]),
                Correo = row["Correo"].ToString(),
                Departamento = row["Departamento"].ToString(),
                Puesto = row["Puesto"].ToString(),
                Salario = Convert.ToDecimal(row["Salario"])
            };
        }

        public bool Guardar(Empleado emp)
        {
            var query = @"INSERT INTO Empleados (Nombre, Apellido, Edad, Correo, Departamento, Puesto, Salario) 
                          VALUES (@Nombre, @Apellido, @Edad, @Correo, @Departamento, @Puesto, @Salario)";
            var parametros = new List<SqlParameter>
            {
                new SqlParameter("@Nombre", emp.Nombre),
                new SqlParameter("@Apellido", emp.Apellido),
                new SqlParameter("@Edad", emp.Edad),
                new SqlParameter("@Correo", emp.Correo),
                new SqlParameter("@Departamento", emp.Departamento),
                new SqlParameter("@Puesto", emp.Puesto),
                new SqlParameter("@Salario", emp.Salario)
            };

            return _db.ExecuteNonQuery(query, parametros) > 0;
        }

        public bool Editar(Empleado emp)
        {
            var query = @"UPDATE Empleados SET Nombre = @Nombre, Apellido = @Apellido, Edad = @Edad, 
                          Correo = @Correo, Departamento = @Departamento, Puesto = @Puesto, Salario = @Salario 
                          WHERE Id = @Id";
            var parametros = new List<SqlParameter>
            {
                new SqlParameter("@Id", emp.Id),
                new SqlParameter("@Nombre", emp.Nombre),
                new SqlParameter("@Apellido", emp.Apellido),
                new SqlParameter("@Edad", emp.Edad),
                new SqlParameter("@Correo", emp.Correo),
                new SqlParameter("@Departamento", emp.Departamento),
                new SqlParameter("@Puesto", emp.Puesto),
                new SqlParameter("@Salario", emp.Salario)
            };

            return _db.ExecuteNonQuery(query, parametros) > 0;
        }

        public bool Eliminar(int id)
        {
            var query = "DELETE FROM Empleados WHERE Id = @Id";
            var parametros = new List<SqlParameter> { new SqlParameter("@Id", id) };

            return _db.ExecuteNonQuery(query, parametros) > 0;
        }
    }
}
