﻿document.addEventListener("DOMContentLoaded", function () {
    // Crear empleado
    const formCrear = document.getElementById("formCrear");
    if (formCrear) {
        formCrear.addEventListener("submit", function (e) {
            e.preventDefault();
            const data = Object.fromEntries(new FormData(formCrear));
            fetch("/Empleados/CrearAjax", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            })
                .then(res => res.json())
                .then(res => {
                    if (res.success) {
                        Swal.fire("¡Éxito!", "Empleado creado correctamente", "success")
                            .then(() => window.location.href = "/Empleados");
                    } else {
                        Swal.fire("Error", "No se pudo crear el empleado", "error");
                    }
                });
        });
    }

    // Editar empleado - abrir modal renderizado desde Razor
    document.querySelectorAll(".btnEditar").forEach(btn => {
        btn.addEventListener("click", function () {
            const id = this.dataset.id;
            fetch(`/Empleados/ModalEditEmpleado?id=${id}`)
                .then(res => res.text())
                .then(html => {
                    document.getElementById("contenedorModal").innerHTML = html;
                    const modal = new bootstrap.Modal(document.getElementById("modalEditarEmpleado"));
                    modal.show();

                    // Asignar evento submit al nuevo formulario
                    const formEditar = document.getElementById("formEditarEmpleado");
                    formEditar.addEventListener("submit", function (e) {
                        e.preventDefault();
                        const data = Object.fromEntries(new FormData(formEditar));
                        fetch("/Empleados/EditarAjax", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify(data)
                        })
                            .then(res => res.json())
                            .then(res => {
                                if (res.success) {
                                    Swal.fire("¡Actualizado!", "Empleado editado correctamente", "success")
                                        .then(() => window.location.href = "/Empleados");
                                } else {
                                    Swal.fire("Error", "No se pudo editar el empleado", "error");
                                }
                            });
                    });
                });
        });
    });

    // Eliminar empleado
    document.querySelectorAll(".btnEliminar").forEach(btn => {
        btn.addEventListener("click", function () {
            const id = this.dataset.id;
            Swal.fire({
                title: "¿Estás seguro?",
                text: "Esta acción no se puede deshacer",
                icon: "warning",
                showCancelButton: true,
                confirmButtonText: "Sí, eliminar",
                cancelButtonText: "Cancelar"
            }).then(result => {
                if (result.isConfirmed) {
                    fetch("/Empleados/EliminarAjax", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify(id)
                    })
                        .then(res => res.json())
                        .then(res => {
                            if (res.success) {
                                Swal.fire("¡Eliminado!", "Empleado eliminado correctamente", "success")
                                    .then(() => window.location.reload());
                            } else {
                                Swal.fire("Error", "No se pudo eliminar el empleado", "error");
                            }
                        });
                }
            });
        });
    });
});
